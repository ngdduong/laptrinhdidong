package com.dev.lishabora.Utils

import android.view.View

/**
 * Created by Eric on 12/18/2017.
 */

interface OnclickRecyclerListener {
    fun onClickListener(position: Int)


}
