package com.kogicodes.sokoni.models.custom


enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}