package com.kogicodes.sokoni.models.custom


enum class MediaType {
    FILTER,
    ALBUM,

}