# AndroidGooglePhotosApi
Demonstrates how to use the newly relieased google photos api in Android client .

Find app on playstore https://play.google.com/store/apps/details?id=ke.co.calista.googlephotos

