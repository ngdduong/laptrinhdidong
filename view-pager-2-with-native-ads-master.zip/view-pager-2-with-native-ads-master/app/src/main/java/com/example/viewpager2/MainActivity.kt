package com.example.viewpager2

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.gms.ads.*
import com.google.android.gms.ads.nativead.NativeAd

class MainActivity : AppCompatActivity() {

    private lateinit var vpSlider: ViewPager2
    private lateinit var ivBackground: ImageView
    private lateinit var sliderAdapter: SliderAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()

        MobileAds.initialize(this) {}
        val adLoader = AdLoader.Builder(this, getString(R.string.nativs_ads_id))
            .forNativeAd { ad : NativeAd ->
                sliderAdapter.setNativeAds(ad)
                sliderAdapter.submitList(addNullValueInsideArray(getWallpapers()))
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    sliderAdapter.submitList(getWallpapers())
                }
            })
            .build()
        adLoader.loadAd(AdRequest.Builder().build())

        sliderAdapter.setOnClickListener(object : SliderInterface{
            override fun onItemClickListener(wallpaper: Int) {
                Glide.with(this@MainActivity)
                    .load(wallpaper)
                    .into(ivBackground)
            }
        })
    }

    private fun addNullValueInsideArray(data: List<Int>): List<Int?>{
        val newData = arrayListOf<Int?>()
        for (i in data.indices){
            if(i % 4 == 0){
                if(i !=0 && i != data.size - 1)
                newData.add(null)
            }
            newData.add(data[i])
        }
        return newData
    }

    private fun initView() {
        vpSlider = findViewById(R.id.vpSlider)
        ivBackground = findViewById(R.id.ivBackground)
        vpSlider.offscreenPageLimit = 3
        vpSlider.setPageTransformer(getTransformation())
        sliderAdapter = SliderAdapter()
        vpSlider.adapter = sliderAdapter
        sliderAdapter.submitList(getWallpapers())
    }

    private fun getTransformation(): CompositePageTransformer{
        val transform = CompositePageTransformer()
        transform.addTransformer(MarginPageTransformer(30))
        transform.addTransformer { page, position ->
            page.scaleY = 0.85f + (1 - kotlin.math.abs(position)) * 0.15f
        }
        return transform
    }

    private fun getWallpapers(): List<Int>{
        val data = arrayListOf<Int>()
        data.add(R.drawable.akuma)
        data.add(R.drawable.alisa)
        data.add(R.drawable.anna)
        data.add(R.drawable.bryan)
        data.add(R.drawable.eliza)
        data.add(R.drawable.jin)
        data.add(R.drawable.josie)
        data.add(R.drawable.julia)
        data.add(R.drawable.king)
        data.add(R.drawable.nina)
        return data
    }

}