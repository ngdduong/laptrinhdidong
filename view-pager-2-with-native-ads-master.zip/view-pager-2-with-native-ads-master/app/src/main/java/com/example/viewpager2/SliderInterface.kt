package com.example.viewpager2

interface SliderInterface {
    fun onItemClickListener(wallpaper: Int)
}