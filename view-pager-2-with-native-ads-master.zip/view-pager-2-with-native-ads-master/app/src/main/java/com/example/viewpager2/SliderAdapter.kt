package com.example.viewpager2

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

class SliderAdapter : ListAdapter<Int,RecyclerView.ViewHolder>(DiffCallback()) {

    private val itemAds = 1
    private val itemWallpaper = 2
    private lateinit var nativeAd: NativeAd
    private lateinit var sliderInterface: SliderInterface

    fun setOnClickListener(sliderInterface: SliderInterface){
        this.sliderInterface = sliderInterface
    }

    fun setNativeAds(nativeAd: NativeAd){
        this.nativeAd = nativeAd
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        private val ivWallpaper: ImageView = itemView.findViewById(R.id.ivWallpaper)
        fun onBind(wallpaper: Int){
            Glide.with(ivWallpaper)
                .load(wallpaper)
                .into(ivWallpaper)
            itemView.setOnClickListener {
                sliderInterface.onItemClickListener(wallpaper)
                Log.d("slider_adapter", "onBind: $adapterPosition")
            }
        }
    }

    inner class AdsHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        fun onBind(){
            showNativeAd(nativeAd,itemView)
        }
    }

    fun showNativeAd(nativeAd: NativeAd,itemView: View){
        itemView.apply {
            nativeAd.apply {
                //Init Native Ads Vies
                val adView: NativeAdView = findViewById(R.id.adView)
                val adMedia: MediaView = findViewById(R.id.adMedia)
                val adHeadline: TextView = findViewById(R.id.adHeadline)
                val adBody: TextView = findViewById(R.id.adBody)
                val adBtnAction: Button = findViewById(R.id.adBtnAction)
                val adAppIcon: ImageView = findViewById(R.id.adAppIcon)
                val adPrice: TextView = findViewById(R.id.adPrice)
                val adStars: RatingBar = findViewById(R.id.adStars)
                val adStore: TextView = findViewById(R.id.adStore)
                val adAdvertiser: TextView = findViewById(R.id.adAdvertiser)
                //Assign position of views inside the native ad view
                adView.mediaView = adMedia
                adView.headlineView = adHeadline
                adView.bodyView = adBody
                adView.callToActionView = adBtnAction
                adView.iconView = adAppIcon
                adView.priceView = adPrice
                adView.starRatingView = adStars
                adView.storeView = adStore
                adView.advertiserView = adAdvertiser
                //Assign Values to View
                adView.mediaView?.setMediaContent(mediaContent!!)
                adView.mediaView?.setImageScaleType(ImageView.ScaleType.CENTER_CROP)
                (adView.headlineView as TextView).text = headline
                (adView.bodyView as TextView).text = body
                (adView.callToActionView as Button).text = callToAction
                (adView.iconView as ImageView).setImageDrawable(icon?.drawable)
                (adView.priceView as TextView).text = price
                (adView.storeView as TextView).text = store
                (adView.starRatingView as RatingBar).rating = starRating!!.toFloat()
                (adView.advertiserView as TextView).text = advertiser
                adView.setNativeAd(this)
            }
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<Int>(){
        override fun areItemsTheSame(oldItem: Int, newItem: Int)  = oldItem == newItem

        override fun areContentsTheSame(oldItem: Int, newItem: Int) = oldItem == newItem

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when(viewType){
            itemAds -> {
                AdsHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_ads,parent,false))
            }
            else -> {
                ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_slider,parent,false))
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = getItem(position)
        if(holder is ViewHolder){
            holder.onBind(item)
        }else if(holder is AdsHolder){
            holder.onBind()
        }
        /*val hold = holder as ViewHolder
        hold.onBind(item)*/
    }

    override fun getItemViewType(position: Int): Int {
        return when(getItem(position)){
            null -> itemAds
            else -> itemWallpaper
        }
    }

}