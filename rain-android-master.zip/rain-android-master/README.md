# Minimal Weather

A simplistic weather application for Android. Retrieves and displays weather data based on the current location of the device.

Weather data is received from FMI open data API (https://en.ilmatieteenlaitos.fi/open-data/)

Weather icons by Erik Flowers (https://erikflowers.github.io/weather-icons/)

App icons generated with Android Asset Studio (https://romannurik.github.io/AndroidAssetStudio/)
