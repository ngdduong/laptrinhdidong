package com.example.viewpager2_;

public class ViewPagerItem {

    int imageID;
    String heading, description;

    public ViewPagerItem(int imageID, String heading, String description) {
        this.imageID = imageID;
        this.heading = heading;
        this.description = description;
    }
}
