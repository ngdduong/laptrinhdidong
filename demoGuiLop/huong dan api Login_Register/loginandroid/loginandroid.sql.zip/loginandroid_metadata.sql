

--
-- Siêu dữ liệu
--
USE `phpmyadmin`;

--
-- Siêu dữ liệu cho bảng registerdemo
--

--
-- Siêu dữ liệu cho cơ sở dữ liệu loginandroid
--
